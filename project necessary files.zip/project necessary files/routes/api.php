<?php

// routes/api.php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TelegramWebhookController;

Route::post('/telegram/webhook', [TelegramWebhookController::class, 'handle']);

return [
    
    'telegram' => [
        'bot_token' => env('TELEGRAM_BOT_TOKEN'),
        'group_chat_id' => env('TELEGRAM_GROUP_CHAT_ID'),
    ],
];