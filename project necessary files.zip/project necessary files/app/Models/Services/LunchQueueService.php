<?php

// app/Services/LunchQueueService.php

namespace App\Services;

use App\Models\User;
use App\Models\LunchSession;
use App\Models\LunchQueue;
use Carbon\Carbon;

class LunchQueueService
{
    public function createLunchSession(string $date = null, string $announcementTime = '12:00'): LunchSession
    {
        $date = $date ?? today()->toDateString();
        
        return LunchSession::create([
            'date' => $date,
            'announcement_time' => $announcementTime,
            'start_time' => '13:00', 
            'max_concurrent_users' => 3, 
            'status' => 'collecting'
        ]);
    }

    public function addUserToQueue(User $user, LunchSession $session): bool
    {
        if ($user->wasInQueueToday()) {
            return false;
        }

        if ($session->status !== 'collecting') {
            return false;
        }
        $position = $session->lunchQueues()->count() + 1;

        LunchQueue::create([
            'lunch_session_id' => $session->id,
            'user_id' => $user->id,
            'position' => $position,
            'status' => 'waiting'
        ]);

        return true;
    }

    public function getNextUsersToNotify(LunchSession $session): array
    {
        $usersAtLunch = $session->getUsersAtLunch();
        $maxConcurrent = $session->max_concurrent_users;
        $canGoToLunch = $maxConcurrent - $usersAtLunch;

        if ($canGoToLunch <= 0) {
            return [];
        }

        return $session->lunchQueues()
            ->where('status', 'waiting')
            ->with('user')
            ->orderBy('position')
            ->take($canGoToLunch)
            ->get()
            ->toArray();
    }

    public function startUserLunch(LunchQueue $queueRecord): bool
    {
        if ($queueRecord->status !== 'notified') {
            return false;
        }

        $queueRecord->update([
            'status' => 'at_lunch',
            'lunch_started_at' => now()
        ]);

        return true;
    }

    public function getUsersNeedingReminder(int $minutesBefore = 5): array
    {
        $reminderTime = now()->subMinutes(30 - $minutesBefore); 

        return LunchQueue::where('status', 'at_lunch')
            ->where('lunch_started_at', '<=', $reminderTime)
            ->with(['user', 'lunchSession'])
            ->get()
            ->toArray();
    }

    public function getSupervisorStats(LunchSession $session): array
    {
        $queue = $session->getCurrentQueue();
        
        return [
            'total_in_queue' => $queue->count(),
            'users_at_lunch' => $session->getUsersAtLunch(),
            'waiting' => $queue->where('status', 'waiting')->count(),
            'finished' => $queue->where('status', 'finished')->count(),
            'queue_list' => $queue->map(function ($item) {
                return [
                    'position' => $item->position,
                    'name' => $item->user->first_name,
                    'status' => $item->status,
                    'started_at' => $item->lunch_started_at?->format('H:i')
                ];
            })->toArray()
        ];
    }
}