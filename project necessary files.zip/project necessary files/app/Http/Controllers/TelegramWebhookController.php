<?php
// app/Http/Controllers/TelegramWebhookController.php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Services\TelegramService;
use App\Services\LunchQueueService;
use App\Models\User;
use App\Models\LunchSession;
use App\Models\LunchQueue;
use Illuminate\Support\Facades\Log;

class TelegramWebhookController extends Controller
{
    private $telegram;
    private $queueService;

    public function __construct(TelegramService $telegram, LunchQueueService $queueService)
    {
        $this->telegram = $telegram;
        $this->queueService = $queueService;
    }

    public function handle(Request $request): JsonResponse
    {
        try {
            $update = $request->all();
            Log::info('Telegram update received', $update);

            // Обрабатываем обычные сообщения
            if (isset($update['message'])) {
                $this->handleMessage($update['message']);
            }

            // Обрабатываем нажатия на кнопки
            if (isset($update['callback_query'])) {
                $this->handleCallbackQuery($update['callback_query']);
            }

            return response()->json(['ok' => true]);
        } catch (\Exception $e) {
            Log::error('Webhook error: ' . $e->getMessage());
            return response()->json(['ok' => false], 500);
        }
    }

    private function handleMessage(array $message): void
    {
        $chatId = $message['chat']['id'];
        $text = $message['text'] ?? '';
        $from = $message['from'];

        // Создаем или обновляем пользователя
        $user = $this->createOrUpdateUser($from);

        // Проверяем супервайзерские команды
        if ($this->handleSupervisorCommands($chatId, $user, $text)) {
            return;
        }

        // Команды бота
        if (strpos($text, '/start') === 0) {
            $this->handleStartCommand($chatId, $user);
        } elseif (strpos($text, '/status') === 0 && $user->isSupervisor()) {
            $this->handleStatusCommand($chatId);
        } elseif (strpos($text, '/queue') === 0) {
            $this->handleQueueCommand($chatId, $user);
        }
    }

    private function handleCallbackQuery(array $callbackQuery): void
    {
        $chatId = $callbackQuery['message']['chat']['id'];
        $data = $callbackQuery['data'];
        $from = $callbackQuery['from'];

        $user = $this->createOrUpdateUser($from);

        // Парсим callback_data
        if (strpos($data, 'join_queue_') === 0) {
            $sessionId = (int) str_replace('join_queue_', '', $data);
            $this->handleJoinQueue($chatId, $user, $sessionId);
        } elseif (strpos($data, 'start_lunch_') === 0) {
            $queueId = (int) str_replace('start_lunch_', '', $data);
            $this->handleStartLunch($chatId, $user, $queueId);
        }
    }

    private function createOrUpdateUser(array $telegramUser): User
    {
        return User::updateOrCreate(
            ['telegram_id' => $telegramUser['id']],
            [
                'first_name' => $telegramUser['first_name'],
                'last_name' => $telegramUser['last_name'] ?? null,
                'username' => $telegramUser['username'] ?? null,
            ]
        );
    }

    private function handleStartCommand(string $chatId, User $user): void
    {
        if ($user->isSupervisor()) {
            $message = "Привет, {$user->first_name}! 👨‍💼\n\n";
            $message .= "Ты супервайзер. Доступные команды:\n";
            $message .= "/status - посмотреть текущую очередь\n";
            $message .= "/queue - управление очередью";
        } else {
            $message = "Привет, {$user->first_name}! 👋\n\n";
            $message .= "Я бот для управления очередью на обед.\n";
            $message .= "Когда объявлю сбор - жми кнопку для записи!";
        }

        $this->telegram->sendMessage($chatId, $message);
    }

    private function handleStatusCommand(string $chatId): void
    {
        $session = LunchSession::where('date', today())
            ->where('status', '!=', 'finished')
            ->latest()
            ->first();

        if (!$session) {
            $this->telegram->sendMessage($chatId, "Сегодня нет активных сессий обеда.");
            return;
        }

        $stats = $this->queueService->getSupervisorStats($session);
        
        $message = "📊 <b>Статус очереди на обед</b>\n\n";
        $message .= "👥 Всего в очереди: {$stats['total_in_queue']}\n";
        $message .= "🍽️ Сейчас на обеде: {$stats['users_at_lunch']}\n";
        $message .= "⏳ Ожидают: {$stats['waiting']}\n";
        $message .= "✅ Завершили: {$stats['finished']}\n\n";
        
        if (!empty($stats['queue_list'])) {
            $message .= "<b>Очередь:</b>\n";
            foreach ($stats['queue_list'] as $item) {
                $status = $this->getStatusEmoji($item['status']);
                $time = $item['started_at'] ? " ({$item['started_at']})" : "";
                $message .= "{$item['position']}. {$item['name']} {$status}{$time}\n";
            }
        }

        $this->telegram->sendMessage($chatId, $message);
    }

    private function handleQueueCommand(string $chatId, User $user): void
    {
        $session = LunchSession::where('date', today())
            ->where('status', 'collecting')
            ->latest()
            ->first();

        if (!$session) {
            $this->telegram->sendMessage($chatId, "Сейчас нет активного сбора на обед.");
            return;
        }

        if ($user->wasInQueueToday()) {
            $this->telegram->sendMessage($chatId, "Ты уже записан в очередь на сегодня! 😊");
            return;
        }

        $keyboard = $this->telegram->createInlineKeyboard(
            $this->telegram->createJoinQueueButton($session->id)
        );

        $message = "🍽️ Хочешь записаться на обед?\n";
        $message .= "Обед начнется в 13:00, продолжительность 30 минут.";

        $this->telegram->sendMessage($chatId, $message, $keyboard);
    }

    private function handleJoinQueue(string $chatId, User $user, int $sessionId): void
    {
        $session = LunchSession::find($sessionId);
        
        if (!$session || $session->status !== 'collecting') {
            $this->telegram->sendMessage($chatId, "Запись в очередь уже закрыта.");
            return;
        }

        $success = $this->queueService->addUserToQueue($user, $session);

        if ($success) {
            $position = $session->lunchQueues()->where('user_id', $user->id)->first()->position;
            $message = "✅ Отлично! Ты записан в очередь на обед.\n";
            $message .= "Твоя позиция: <b>#{$position}</b>\n\n";
            $message .= "Я уведомлю тебя, когда подойдет твоя очередь! 🔔";
        } else {
            $message = "❌ Не удалось записаться. Возможно, ты уже был в очереди сегодня.";
        }

        $this->telegram->sendMessage($chatId, $message);
    }

    private function handleStartLunch(string $chatId, User $user, int $queueId): void
    {
        $queueRecord = LunchQueue::where('id', $queueId)
            ->where('user_id', $user->id)
            ->first();

        if (!$queueRecord) {
            $this->telegram->sendMessage($chatId, "Запись не найдена.");
            return;
        }

        $success = $this->queueService->startUserLunch($queueRecord);

        if ($success) {
            $message = "🍽️ Приятного аппетита!\n";
            $message .= "Обед начался в " . now()->format('H:i') . "\n";
            $message .= "Не забудь вернуться через 30 минут! ⏰";
        } else {
            $message = "❌ Ошибка при подтверждении обеда.";
        }

        $this->telegram->sendMessage($chatId, $message);
    }

    private function getStatusEmoji(string $status): string
    {
        return match($status) {
            'waiting' => '⏳',
            'notified' => '🔔',
            'at_lunch' => '🍽️',
            'finished' => '✅',
            default => '❓'
        };
    }

    private function handleSupervisorCommands(string $chatId, User $user, string $text): bool
    {
        if (!$user->isSupervisor()) {
            return false;
        }

        if (strpos($text, '/setlimit') === 0) {
            // /setlimit 5 - установить максимум 5 человек одновременно
            $parts = explode(' ', $text);
            if (count($parts) >= 2 && is_numeric($parts[1])) {
                $limit = (int) $parts[1];
                $this->updateConcurrentLimit($chatId, $limit);
                return true;
            }
            
            $this->telegram->sendMessage($chatId, "❌ Используй: /setlimit 3");
            return true;
        }

        if (strpos($text, '/cancel') === 0) {
            // Отменить текущую сессию
            $this->cancelCurrentSession($chatId);
            return true;
        }

        if (strpos($text, '/help') === 0) {
            $this->showSupervisorHelp($chatId);
            return true;
        }

        return false;
    }

    private function updateConcurrentLimit(string $chatId, int $limit): void
    {
        $session = LunchSession::where('date', today())
            ->where('status', '!=', 'finished')
            ->latest()
            ->first();

        if ($session) {
            $session->update(['max_concurrent_users' => $limit]);
            $message = "✅ Лимит одновременных обедов изменен на: <b>{$limit}</b>";
        } else {
            $message = "❌ Нет активной сессии для изменения";
        }

        $this->telegram->sendMessage($chatId, $message);
    }

    private function cancelCurrentSession(string $chatId): void
    {
        $session = LunchSession::where('date', today())
            ->where('status', 'collecting')
            ->latest()
            ->first();

        if ($session) {
            $session->update(['status' => 'finished']);
            
            // Уведомляем пользователей в очереди
            $queueUsers = $session->lunchQueues()->with('user')->get();
            foreach ($queueUsers as $queueRecord) {
                $message = "❌ Сбор на обед отменен супервайзером.";
                $this->telegram->sendMessage($queueRecord->user->telegram_id, $message);
            }
            
            $message = "✅ Текущая сессия отменена. Уведомлено пользователей: " . $queueUsers->count();
        } else {
            $message = "❌ Нет активной сессии для отмены";
        }

        $this->telegram->sendMessage($chatId, $message);
    }

    private function showSupervisorHelp(string $chatId): void
    {
        $message = "👨‍💼 <b>Команды супервайзера:</b>\n\n";
        $message .= "/status - текущий статус очереди\n";
        $message .= "/setlimit 3 - установить лимит одновременных обедов\n";
        $message .= "/cancel - отменить текущий сбор\n";
        $message .= "/help - показать эту справку";
        
        $this->telegram->sendMessage($chatId, $message);
    }
}