<?php
// app/Console/Commands/SendLunchAnnouncement.php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Services\TelegramService;
use App\Services\LunchQueueService;

class SendLunchAnnouncement extends Command
{
    protected $signature = 'lunch:announce';
    protected $description = 'Отправить объявление о сборе на обед в группу';

    private $telegram;
    private $queueService;

    public function __construct(TelegramService $telegram, LunchQueueService $queueService)
    {
        parent::__construct();
        $this->telegram = $telegram;
        $this->queueService = $queueService;
    }

    public function handle()
    {
        try {
            // Создаем новую сессию обеда
            $session = $this->queueService->createLunchSession();
            
            // ID группового чата (нужно получить и добавить в .env)
            $groupChatId = config('services.telegram.group_chat_id');
            
            $message = "🍽️ <b>Объявляю сбор на обед!</b>\n\n";
            $message .= "⏰ Время: 13:00 - 13:30\n";
            $message .= "👥 Одновременно: до 3 человек\n";
            $message .= "📝 Для записи нажми кнопку ниже или напиши /queue";
            
            // Создаем кнопку для записи
            $keyboard = $this->telegram->createInlineKeyboard(
                $this->telegram->createJoinQueueButton($session->id)
            );
            
            $success = $this->telegram->sendMessage($groupChatId, $message, $keyboard);
            
            if ($success) {
                $this->info("✅ Объявление отправлено в группу!");
            } else {
                $this->error("❌ Ошибка отправки объявления");
            }
            
        } catch (\Exception $e) {
            $this->error("Ошибка: " . $e->getMessage());
        }
    }
}

