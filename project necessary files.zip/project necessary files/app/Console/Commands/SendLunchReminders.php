<?php

// app/Console/Commands/SendLunchReminders.php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Services\TelegramService;
use App\Services\LunchQueueService;

class SendLunchReminders extends Command
{
    protected $signature = 'lunch:remind';
    protected $description = 'Отправить напоминания об окончании обеда';

    private $telegram;
    private $queueService;

    public function __construct(TelegramService $telegram, LunchQueueService $queueService)
    {
        parent::__construct();
        $this->telegram = $telegram;
        $this->queueService = $queueService;
    }

    public function handle()
    {
        try {
            // Напоминание за 5 минут
            $this->sendReminders(5);
            
            // Автоматически завершаем обед для тех, кто превысил время
            $this->finishOverdueLunches();
            
        } catch (\Exception $e) {
            $this->error("Ошибка отправки напоминаний: " . $e->getMessage());
        }
    }

    private function sendReminders(int $minutesBefore)
    {
        $users = $this->queueService->getUsersNeedingReminder($minutesBefore);
        
        foreach ($users as $userData) {
            $queueRecord = \App\Models\LunchQueue::find($userData['id']);
            $user = $queueRecord->user;
            $remainingTime = $queueRecord->getRemainingLunchTime();
            
            if ($remainingTime > 0 && $remainingTime <= $minutesBefore) {
                $message = "⏰ <b>Напоминание об обеде</b>\n\n";
                $message .= "Осталось времени: <b>{$remainingTime} мин.</b>\n";
                $message .= "Не забудь вернуться на рабочее место! 🏃‍♂️";
                
                $this->telegram->sendMessage($user->telegram_id, $message);
                $this->info("⏰ Напоминание отправлено: {$user->first_name}");
            }
        }
    }

    private function finishOverdueLunches()
    {
        $overdueUsers = \App\Models\LunchQueue::where('status', 'at_lunch')
            ->where('lunch_started_at', '<=', now()->subMinutes(30))
            ->with(['user', 'lunchSession'])
            ->get();

        foreach ($overdueUsers as $queueRecord) {
            // Автоматически завершаем обед
            $queueRecord->update([
                'status' => 'finished',
                'lunch_finished_at' => now()
            ]);
            
            // Уведомляем пользователя
            $message = "🚨 <b>Время обеда истекло!</b>\n\n";
            $message .= "Пожалуйста, вернись на рабочее место.";
            
            $this->telegram->sendMessage($queueRecord->user->telegram_id, $message);
            
            // Уведомляем супервайзеров
            $this->notifySupervisorsAboutOverdue($queueRecord->user);
            
            $this->warn("⚠️ Автоматически завершен обед: {$queueRecord->user->first_name}");
        }
    }

    private function notifySupervisorsAboutOverdue($user)
    {
        $supervisors = \App\Models\User::where('role', 'supervisor')->get();
        
        foreach ($supervisors as $supervisor) {
            $message = "🚨 <b>Превышение времени обеда</b>\n\n";
            $message .= "👤 {$user->first_name} превысил время обеда\n";
            $message .= "⏰ Автоматически завершено в " . now()->format('H:i');
            
            $this->telegram->sendMessage($supervisor->telegram_id, $message);
        }
    }
}