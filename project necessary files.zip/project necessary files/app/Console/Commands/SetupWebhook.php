<?php

// app/Console/Commands/SetupWebhook.php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Services\TelegramService;
use GuzzleHttp\Client;

class SetupWebhook extends Command
{
    protected $signature = 'telegram:webhook {--delete}';
    protected $description = 'Настроить webhook для Telegram бота';

    public function handle()
    {
        try {
            $client = new Client();
            $botToken = config('services.telegram.bot_token');
            
            if ($this->option('delete')) {
                // Удаляем webhook
                $response = $client->post("https://api.telegram.org/bot{$botToken}/deleteWebhook");
                $this->info("✅ Webhook удален");
                return;
            }

            // Устанавливаем webhook
            $webhookUrl = config('app.url') . '/api/telegram/webhook';
            
            $response = $client->post("https://api.telegram.org/bot{$botToken}/setWebhook", [
                'json' => [
                    'url' => $webhookUrl,
                    'allowed_updates' => ['message', 'callback_query']
                ]
            ]);

            $result = json_decode($response->getBody(), true);
            
            if ($result['ok']) {
                $this->info("✅ Webhook установлен: {$webhookUrl}");
            } else {
                $this->error("❌ Ошибка установки webhook: " . $result['description']);
            }
            
        } catch (\Exception $e) {
            $this->error("Ошибка: " . $e->getMessage());
        }
    }
}
