<?php
// app/Console/Commands/ProcessLunchQueue.php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Services\TelegramService;
use App\Services\LunchQueueService;
use App\Models\LunchSession;
use App\Models\LunchQueue;

class ProcessLunchQueue extends Command
{
    protected $signature = 'lunch:process';
    protected $description = 'Обработать очередь на обед - уведомить следующих';

    private $telegram;
    private $queueService;

    public function __construct(TelegramService $telegram, LunchQueueService $queueService)
    {
        parent::__construct();
        $this->telegram = $telegram;
        $this->queueService = $queueService;
    }

    public function handle()
    {
        try {
            // Находим активные сессии
            $sessions = LunchSession::where('date', today())
                ->where('status', 'active')
                ->get();

            foreach ($sessions as $session) {
                $this->processSession($session);
            }

            // Запускаем сессии, если время пришло
            $this->startSessionsIfTime();
            
        } catch (\Exception $e) {
            $this->error("Ошибка обработки очереди: " . $e->getMessage());
        }
    }

    private function processSession(LunchSession $session)
    {
        $usersToNotify = $this->queueService->getNextUsersToNotify($session);
        
        foreach ($usersToNotify as $userData) {
            $queueRecord = LunchQueue::find($userData['id']);
            $user = $queueRecord->user;
            
            // Отправляем уведомление
            $message = "🔔 <b>Твоя очередь на обед!</b>\n\n";
            $message .= "Время: " . now()->format('H:i') . "\n";
            $message .= "Продолжительность: 30 минут\n\n";
            $message .= "Подтверди, что идешь на обед:";
            
            $keyboard = $this->telegram->createInlineKeyboard(
                $this->telegram->createLunchConfirmationButtons($queueRecord->id)
            );
            
            $success = $this->telegram->sendMessage(
                $user->telegram_id, 
                $message, 
                $keyboard
            );
            
            if ($success) {
                // Помечаем как уведомленного
                $queueRecord->update([
                    'status' => 'notified',
                    'notified_at' => now()
                ]);
                
                $this->info("✅ Уведомлен: {$user->first_name}");
                
                // Уведомляем супервайзеров
                $this->notifySupervisors($user, $session);
            }
        }
    }

    private function startSessionsIfTime()
    {
        $sessionsToStart = LunchSession::where('date', today())
            ->where('status', 'collecting')
            ->where('start_time', '<=', now()->format('H:i'))
            ->get();

        foreach ($sessionsToStart as $session) {
            $session->update(['status' => 'active']);
            $this->info("🚀 Запущена сессия: " . $session->start_time);
        }
    }

    private function notifySupervisors($user, $session)
    {
        $supervisors = \App\Models\User::where('role', 'supervisor')->get();
        
        foreach ($supervisors as $supervisor) {
            $message = "👨‍💼 <b>Уведомление супервайзеру</b>\n\n";
            $message .= "🍽️ {$user->first_name} идет на обед\n";
            $message .= "⏰ Время: " . now()->format('H:i');
            
            $this->telegram->sendMessage($supervisor->telegram_id, $message);
        }
    }
}